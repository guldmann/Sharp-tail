﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OptionalParamTest
{
    class Program
    {
        static void Main(string[] args)
        {


            Testa("123", "SE");


            Testa("123", "");

            Testa("");


        }

        public static void Testa(string a, OptionalCountryString b = new OptionalCountryString())
        {
            Console.WriteLine(b.Value);
            Console.WriteLine($"A = {a} B = {b}");
        }
    }



    public struct OptionalCountryString
    {
        private readonly string _value;  

        public OptionalCountryString(string value)
        {
            _value = value;
        }

        public static explicit operator string(OptionalCountryString optionalCountryString)
        {
            return optionalCountryString._value;
        }

        public static implicit operator OptionalCountryString(string value)
        {
            return new OptionalCountryString(value);
        }

        public string Value
        {
            get
            {
                if (string.IsNullOrEmpty(_value))return "at";

                return _value;
            }
        }

        public override string ToString()
        {
            return Value;
        }
    }
}
