﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ActionTest
{
    public static class Actions
    {
        public static bool MyAction<T>(Action<T> myMethod, T message, int attempts, int delay = 0)
        {
            for (var i = 1; i <= attempts; i++)
            {
                try
                {
                    myMethod(message);
                    return true;
                }
                catch (Exception e)
                {
                    if (i < attempts)
                    {
                        Console.WriteLine($"{nameof(myMethod)} Log attempt: {i}");
                        Thread.Sleep(delay);
                    }
                    else
                    {
                        Console.WriteLine($"Total Fail");
                        return false;
                    }
                }
            }

            return false;
        }

        public static bool MyTest<T>(Func<T, bool> myMethod, T message)
        {
            const int attempts = 4;
            for (var i = 1; i <= attempts; i++)
            {
                try
                {
                    myMethod(message);
                    return true;
                }
                catch (Exception e)
                {
                    if (i < 4)
                    {
                        Console.WriteLine($"{nameof(myMethod)} Log {i}");
                    }
                    else
                    {
                        Console.WriteLine($"Total Fail");
                        return false;
                    }
                }
            }

            return false;
        }
    }
}
