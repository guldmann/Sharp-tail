﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ActionTest
{
    public class MyOtherClass
    {
        public bool MyTestMethod(string message)
        {
            throw new Exception("message Error");
        }

        public bool TrueMethod(string message)
        {
            Console.WriteLine(message);
            return true;
        }

        public void Print(string message)
        {
            Console.WriteLine(message);
        }
        public void PrintException(string message)
        {
            Console.WriteLine(message);
            throw new Exception($"Error {message}");
        }
    }
}
