﻿using System;

namespace ActionTest
{
    class Program
    {
        static void Main(string[] args)
        {
            MyOtherClass my  = new MyOtherClass();

           var result  =  Actions.MyTest(my.MyTestMethod, "this is a test message");

            Console.WriteLine(result);

            result = Actions.MyTest(my.TrueMethod, "This is a test");

            Console.WriteLine(result);


            result = Actions.MyAction(my.Print, "This is print",10,10);
            Console.WriteLine(result);

            result = Actions.MyAction(my.PrintException, "This is print", 10, 10);
            Console.WriteLine(result);

            result = Actions.MyAction(MyPrivate, "This is private", 10, 10);
            Console.WriteLine(result);


            Console.WriteLine(tester(false));

            Console.WriteLine(tester(true));


        }

        private static void MyPrivate(string message)
        {
            Console.WriteLine(message);
            throw new Exception(message + "Error");
        }


        private static bool tester(bool b)
        {
            MyOtherClass my = new MyOtherClass();
            return b && Actions.MyAction(my.Print, "tester bool", 10,10);
        }

    }
}
